//COLOR
const c1="rgb(200,200,200)";
const c2="rgb(150,150,150)";
const c3="rgb(40,40,40)";
//INITIALIZE
const canvas=document.getElementById('scene1');
const div=document.getElementById('scene2');
const ctx=canvas.getContext('2d');
//VARIABLES
let player={};
let ai={};
let ball={};
let touch=false;
let touchPos=[0,0];
let playerScore=0;
let aiScore=0;
//TOUCH EVENT
canvas.addEventListener('touchstart',(e)=>{
  touch=true;
  touchPos=[e.touches[0].clientX*4,e.touches[0].clientY*4];
});
canvas.addEventListener('touchmove',(e)=>{
  e.preventDefault();
  touchPos=[e.touches[0].clientX*4,e.touches[0].clientY*4];
});
canvas.addEventListener('touchend',(e)=>{touch=false});
//FUNCTIONS
function restart(all){
  if(all){
    canvas.style.display="flex";
    div.style.display="none";
    playerScore=0;
    aiScore=0;
    ball={
      pos: [1000,500],
      radius: 35,
      vel: [0,0],
      max: 12
    };
    player={
    pos: [50,400],
    size: [25,150],
    vel: 6
  };
    ai={
    pos: [1850,400],
    size: [25,150],
    vel: 7
  };
    generate();
  }
  else{
    ball={
    pos: [1000,500],
    radius: 35,
    vel: [0,0],
    max: 10
  };
  }
}
function generate(){
  const rand1=Math.floor(Math.random()*2);
  const rand2=Math.floor(Math.random()*2);
  ball.vel=rand1==0?(rand2==0?[-5,-5]:[-5,5]):(rand2==0?[5,-5]:[5,5]);
}
function draw(){
  ctx.clearRect(0,0,2000,2000);
  ctx.fillStyle=c1;
  ctx.fillRect(player.pos[0],player.pos[1],player.size[0],player.size[1]);
  ctx.fillRect(ai.pos[0],ai.pos[1],ai.size[0],ai.size[1]);
  ctx.fillStyle=c3;
  ctx.beginPath();
  ctx.arc(ball.pos[0],ball.pos[1],ball.radius,0,Math.PI*2);
  ctx.fill();
  ctx.closePath();
  ctx.fillStyle=c1;
  ctx.font="150px Georgia";
  ctx.fillText(playerScore+"",500,250);
  ctx.fillText(aiScore+"",1500,250);
}
function update(){
  if(ai.pos[1]<=810&&ai.pos[1]<ball.pos[1]){
    ai.pos[1]+=ai.vel;
  }else if(ai.pos[1]>=0&&ai.pos[1]>ball.pos[1]){
    ai.pos[1]-=ai.vel;
  }
  if(ball.pos[1]-ball.radius<=0||ball.pos[1]+ball.radius>=975){
    ball.vel[1]*=-1;
  }
  if(ball.pos[0]-ball.radius<player.pos[0]+player.size[0]&&ball.pos[0]+ball.radius>player.pos[0]&&ball.pos[1]-ball.radius<player.pos[1]+player.size[1]&&ball.pos[1]+ball.radius>player.pos[1]){
    ball.vel[0]=(Math.abs(ball.vel[0])<ball.max?Math.abs(ball.vel[0])+2:Math.abs(ball.vel[0]))*Math.sign(ball.vel[0]);
    ball.vel[1]=(Math.abs(ball.vel[1])<ball.max?Math.abs(ball.vel[1])+2:Math.abs(ball.vel[1]))*Math.sign(ball.vel[1]);
    ball.vel[0]*=-1;
    ball.pos[0]+=25;
  }else if(ball.pos[0]+ball.radius>ai.pos[0]&&ai.pos[0]+ai.size[0]>ball.pos[0]-ball.radius&&ball.pos[1]+ball.radius>ai.pos[1]&&ai.pos[1]+ai.size[1]>ball.pos[1]-ball.radius){
    ball.vel[0]=(Math.abs(ball.vel[0])<ball.max?Math.abs(ball.vel[0])+2:Math.abs(ball.vel[0]))*Math.sign(ball.vel[0]);
    ball.vel[1]=(Math.abs(ball.vel[1])<ball.max?Math.abs(ball.vel[1])+2:Math.abs(ball.vel[1]))*Math.sign(ball.vel[1]);
    ball.vel[0]*=-1;
    ball.pos[0]-=25;
  }
  ball.pos[0]+=ball.vel[0];
  ball.pos[1]+=ball.vel[1];
}
function event(){
  if(touch&&touchPos[1]<=500&&player.pos[1]>=0){
    player.pos[1]-=player.vel;
  }else if(touch&&touchPos[1]>=500&&player.pos[1]<=810){
    player.pos[1]+=player.vel;
  }
}
function detect(){
  if(ball.pos[0]-ball.radius<=-100){
    aiScore+=1;
    restart(false);
    ball.vel[0]=-5;
    ball.vel[1]=Math.floor(Math.random()*2)==0?-5:5;
  }else if(ball.pos[0]+ball.radius>=2000){
    playerScore+=1;
    restart(false);
    ball.vel[0]=5;
    ball.vel[1]=Math.floor(Math.random()*2)==0?-5:5;
  }
  if(playerScore>=5||aiScore>=5){
    canvas.style.display="none";
    div.style.display="flex";
    document.getElementsByClassName('scene2')[0].innerText=playerScore>=5?"VOCÊ GANHOU!":"VOCÊ PERDEU!";
  }
}
function initialize(){
  requestAnimationFrame(initialize);
  draw();
  update();
  event();
  detect();
}
restart(true);
initialize();