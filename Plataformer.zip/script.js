const c=document.getElementById('screen').getContext('2d');
var touch=false;
var touchPos=[[0,0]];
c.canvas.ontouchstart=function(e){
  touch=true;
  touchPos=Array.from(e.touches).map(Touch=>[Touch.clientX*3.3,Touch.clientY*3.4]);
}
c.canvas.ontouchmove=function(e){
  touch=true;
  e.preventDefault();
  touchPos=Array.from(e.touches).map(Touch=>[Touch.clientX*3.3,Touch.clientY*3.4]);
}
c.canvas.ontouchend=function(e){touch=false}
class GameObject{
  #te
  constructor(x,y,width,height,color,touchEnable=false){
    this.x=x;
    this.y=y;
    this.w=width;
    this.h=height;
    this.color=color;
    this.#te=touchEnable;
    this.touch=false;
  }
  draw({x,y}){
    c.fillStyle=this.color;
    c.fillRect(this.x-x,this.y-y,this.w,this.h);
  }
  update(){
    if(this.#te){
      if(touch&&touchPos[0][0]>this.x&&touchPos[0][0]<this.x+this.w&&touchPos[0][1]>this.y&&touchPos[0][1]<this.y+this.h){
        this.touch=true;
      }
      else{this.touch=false}
    }
  }
}
const player=new GameObject(250,680,100,100,'#00f');
const ground=new GameObject(0,770,1975,200,'green');
const btn_l=new GameObject(50,800,100,100,'#0f0',true);
const btn_r=new GameObject(250,800,100,100,'#0f0',true);
const btn_j=new GameObject(1800,800,100,100,'#0f0',true);
const camera={x:0,y:0};
const viewPos={x:250,y:680};
function draw(cam){
  player.draw(cam);
  ground.draw(cam);
  btn_r.draw({x:0,y:0});
  btn_l.draw({x:0,y:0});
  btn_j.draw({x:0,y:0});
}
function update(){
  requestAnimationFrame(update);
  c.clearRect(0,0,2000,1000);
  draw(camera);
  btn_r.update();
  btn_l.update();
  btn_j.update();
  camera.x=player.x-viewPos.x;
  camera.y=player.y-viewPos.y;
  detect();
}
function detect(){
  if(btn_r.touch){
    player.x+=10;
  }
  if(btn_l.touch){
    player.x-=10;
  }
  if(btn_j.touch&&player.y>=680){
    player.y-=200;
  }
  if(player.y<680){
    player.y+=7;
  }
}
update();