const canvas=document.querySelector('canvas');
const ctx=canvas.getContext('2d');
var touch=false;
var touchPos=[0,0];
canvas.addEventListener('touchstart',(e)=>{
  touch=true;
  touchPos=[e.touches[0].clientX*4,e.touches[0].clientY*4];
});
canvas.addEventListener('touchmove',(e)=>{
  e.preventDefault();
  touchPos=[e.touches[0].clientX*4,e.touches[0].clientY*4];
});
canvas.addEventListener('touchend',(e)=>{touch=false;});
function draw(){
  ctx.clearRect(0,0,2000,2000);
}
function update(){
  event();
}
function event(){
  
}
function init(){
  requestAnimationFrame(init);
  update();
  draw();
}
init();