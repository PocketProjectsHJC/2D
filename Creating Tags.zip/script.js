class LogicDevice extends HTMLElement{
  constructor(){
    super();
    this.innerText="GATE"
    this.attachShadow({mode:'open'});
    this.shadowRoot.innerHTML=`
    <style>
      :host{
        display: inline-block;
        position: absolute;
        left: var(--x,0);
        top: var(--y,0);
        width: var(--width,30px);
        height: var(--height,10px);
        background-color: var(--color1,gray);
        color: var(--color2,white);
        align-content: center;
        text-align: center;
        font-size: calc(min(var(--width,30px),var(--height,10px))/1.5);
      }
    </style>
    <slot></slot>
    `;
  }
  static get observedAttributes(){
    return ['pos','size','color1','color2','name'];
  }
  attributeChangedCallback(name,oldValue,newValue){
    if(name==='pos'){
      const [x,y]=newValue.split(',');
      this.style.setProperty('--x',x.trim());
      this.style.setProperty('--y',y.trim());
    }else if(name==='size'){
      const [w,h]=newValue.split(',');
      this.style.setProperty('--width',w.trim());
      this.style.setProperty('--height',h.trim());
    }else if(name==='color1'){
      this.style.setProperty('--color1',newValue.trim());
    }else if(name==='color2'){
      this.style.setProperty('--color2',newValue.trim());
    }else if(name==='name'){
      this.innerText=newValue;
    }
  }
  set pos(value){
    this.setAttribute('pos',value);
  }
  set size(value){
    this.setAttribute('size',value);
  }
  set color1(value){
    this.setAttribute('color1',value);
  }
  set color2(value){
    this.setAttribute('color2',value);
  }
  set name(value){
    this.setAttribute('name',value);
  }
}
customElements.define('logic-device',LogicDevice);